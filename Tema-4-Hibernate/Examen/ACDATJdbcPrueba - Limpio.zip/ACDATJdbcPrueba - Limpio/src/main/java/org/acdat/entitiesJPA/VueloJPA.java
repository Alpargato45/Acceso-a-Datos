package org.acdat.entitiesJPA;
import java.sql.Date;

public class VueloJPA {
    public VueloJPA() {
    }
}
